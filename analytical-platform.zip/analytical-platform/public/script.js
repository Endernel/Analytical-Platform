document.getElementById('dataForm').addEventListener('submit', async (event) => {
  event.preventDefault();

  const field = document.getElementById('field').value;
  const start_date = document.getElementById('start_date').value;
  const end_date = document.getElementById('end_date').value;
  const chartType = document.getElementById('chartType').value;

  const response = await fetch(`/api/measurements?field=${field}&start_date=${start_date}&end_date=${end_date}`);
  const data = await response.json();

  const labels = data.map(entry => new Date(entry.timestamp).toLocaleDateString());
  const values = data.map(entry => entry[field]);

  if (window.myChart) {
    window.myChart.destroy();
  }

  const backgroundColors = chartType === 'pie' ? [
    'rgba(255, 192, 203, 0.6)',
    'rgba(255, 105, 180, 0.6)',
    'rgba(220, 20, 60, 0.6)',
    'rgba(255, 20, 147, 0.6)',
    'rgba(255, 228, 225, 0.6)',
    'rgba(255, 182, 193, 0.6)',
    'rgba(240, 128, 128, 0.6)',
    'rgba(255, 99, 71, 0.6)'
  ] : ['rgba(255, 105, 180, 0.6)'];

  window.myChart = new Chart(document.getElementById('chart'), {
    type: chartType,
    data: {
      labels,
      datasets: [{
        label: `Sales for ${field}`,
        data: values,
        backgroundColor: backgroundColors,
        borderColor: 'rgb(255, 105, 180)',
        borderWidth: 1
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: {
          position: 'top',
        },
        title: {
          display: true,
          text: `Sales for ${field} from ${start_date} to ${end_date}`
        }
      }
    }
  });

  const average = values.reduce((a, b) => a + b, 0) / values.length || 0;
  const min = Math.min(...values);
  const max = Math.max(...values);
  const stdDev = Math.sqrt(values.reduce((acc, val) => acc + Math.pow(val - average, 2), 0) / values.length || 0);

  document.getElementById('average').innerText = `Average: ${average.toFixed(2)}`;
  document.getElementById('min').innerText = `Minimum: ${min}`;
  document.getElementById('max').innerText = `Maximum: ${max}`;
  document.getElementById('stdDev').innerText = `Standard Deviation: ${stdDev.toFixed(2)}`;
});