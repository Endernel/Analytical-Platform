const mongoose = require('mongoose');

mongoose.connect('mongodb+srv://aneleka87:yxCmaJI9AaxxWpwY@cluster0.qe3k9.mongodb.net/your_database?retryWrites=true&w=majority', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(() => console.log("Connected to MongoDB"))
  .catch((err) => console.error("Failed to connect to MongoDB", err));

const measurementSchema = new mongoose.Schema({
  timestamp: { type: Date, required: true },
  Shop1: { type: Number, required: true },
  Shop2: { type: Number, required: true },
  Shop3: { type: Number, required: true },
});
const Measurement = mongoose.model('Measurement', measurementSchema);

async function insertData() {
  const data = [
    { timestamp: new Date('2024-10-01T00:00:00Z'), Shop1: 5, Shop2: 8, Shop3: 3 },
    { timestamp: new Date('2024-10-02T00:00:00Z'), Shop1: 1, Shop2: 6, Shop3: 4 },
    { timestamp: new Date('2024-10-03T00:00:00Z'), Shop1: 6, Shop2: 0, Shop3: 9 },
    { timestamp: new Date('2024-10-04T00:00:00Z'), Shop1: 4, Shop2: 7, Shop3: 6 },
    { timestamp: new Date('2024-10-05T00:00:00Z'), Shop1: 8, Shop2: 5, Shop3: 3 },
    { timestamp: new Date('2024-10-06T00:00:00Z'), Shop1: 10, Shop2: 8, Shop3: 4 },
    { timestamp: new Date('2024-10-07T00:00:00Z'), Shop1: 5, Shop2: 6, Shop3: 7 },
    { timestamp: new Date('2024-10-08T00:00:00Z'), Shop1: 0, Shop2: 0, Shop3: 0 },
    { timestamp: new Date('2024-10-09T00:00:00Z'), Shop1: 3, Shop2: 9, Shop3: 6 },
    { timestamp: new Date('2024-10-10T00:00:00Z'), Shop1: 4, Shop2: 10, Shop3: 7 },
  ];
  await Measurement.insertMany(data);
  console.log("Data inserted");
  mongoose.connection.close();
}
insertData();


