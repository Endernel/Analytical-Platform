const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const app = express();

mongoose.connect('YOUR_MONGODB_CONNECTION_URL', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(() => console.log("Connected to MongoDB"))
  .catch((err) => console.error("Failed to connect to MongoDB", err));

const PORT = 5000;

app.use(express.static(path.join(__dirname, 'public')));

const measurementSchema = new mongoose.Schema({
  timestamp: { type: Date, required: true },
  Shop1: { type: Number, required: true },
  Shop2: { type: Number, required: true },
  Shop3: { type: Number, required: true },
});
const Measurement = mongoose.model('Measurement', measurementSchema);

app.get('/api/measurements', async (req, res) => {
  const { field, start_date, end_date } = req.query;
  const filter = {
    timestamp: { $gte: new Date(start_date), $lte: new Date(end_date) },
  };

  try {
    const data = await Measurement.find(filter).select(`timestamp ${field}`);
    res.json(data);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

app.get('/api/statistics', async (req, res) => {
  const { field, start_date, end_date } = req.query;
  const filter = {
    timestamp: { $gte: new Date(start_date), $lte: new Date(end_date) },
  };

  try {
    const data = await Measurement.find(filter).select(field);
    const values = data.map(entry => entry[field]);
    const average = values.reduce((a, b) => a + b, 0) / values.length;
    const min = Math.min(...values);
    const max = Math.max(...values);
    const stdDev = Math.sqrt(values.reduce((sum, value) => sum + Math.pow(value - average, 2), 0) / values.length);

    res.json({
      average,
      min,
      max,
      stdDev,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});

